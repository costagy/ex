<html> 

<meta http-equiv="refresh" content="3;url=consulte-sua-fatura.php" />


<div>

     <div id="loading"></div>
	 
	 <style>
    #loading {
    background: url('carregando.gif') no-repeat center center;
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    z-index: 9999999;
    }
    </style>
	
<script>															  
															  
function hideLoader()

$(window).ready(hideLoader);
setTimeout(hideLoader, 20 * 2000);
</script>

</div>
</html>